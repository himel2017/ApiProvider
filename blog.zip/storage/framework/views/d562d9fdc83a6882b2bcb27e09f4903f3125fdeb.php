<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title><?php echo $__env->yieldContent("title"); ?> | Akij Group Admin Panel</title>
	<!-- base:css -->
	
	<link rel="stylesheet" href="/assets/vendors/mdi/css/materialdesignicons.min.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" href="https://cdn.materialdesignicons.com/3.6.95/css/materialdesignicons.min.css">

	<link rel="stylesheet" href="/assets/vendors/flag-icon-css/css/flag-icon.min.css">

	<link rel="stylesheet" href="/assets/css/vertical-layout-light/style.css">
	<!-- endinject -->
	<link rel="shortcut icon" href="/assets/images/favicon.png" />
</head>
<body>
	<div class="container-scroller">
		<!-- partial:partials/_navbar.html -->
		<?php echo $__env->make("layouts.partials.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- partial -->
		<div class="container-fluid page-body-wrapper">

			<!-- partial:partials/_sidebar.html -->
			<?php echo $__env->make("layouts.partials.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- partial -->
			<div class="main-panel">
				<div class="content-wrapper">
				
				<div id="confirmation-message"><?php echo session()->get("message"); ?></div>
				
				<?php echo $__env->yieldContent("content"); ?>
				
				
				
				</div>
				<!-- content-wrapper ends -->
				<!-- partial:partials/_footer.html -->
		<div class="footer-wrapper">
		<footer class="footer">
			<div class="d-sm-flex justify-content-center justify-content-sm-between">
			<span class="text-center text-sm-left d-block d-sm-inline-block">Copyright &copy; 2019. All rights reserved. </span>
			<span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Designed by: <a href="https://www.urbanui.com/" target="_blank">UrbanUI</a>. </span>
			</div>
		</footer>
		</div>
		<!-- partial -->
			<!-- main-panel ends -->
			</div>
		<!-- page-body-wrapper ends -->
		</div>
	</div>
	<!-- container-scroller -->
	<!-- base:js -->
	<script src="/assets/vendors/js/vendor.bundle.base.js"></script>
	<!-- endinject -->
	<!-- Plugin js for this page-->
	<script src="/assets/vendors/progressbar.js/progressbar.min.js"></script>
	<script src="/assets/vendors/flot/jquery.flot.js"></script>
	<script src="/assets/vendors/flot/jquery.flot.resize.js"></script>
	<script src="/assets/vendors/flot/curvedLines.js"></script>
	<script src="/assets/vendors/chart.js/Chart.min.js"></script>
	<!-- End plugin js for this page-->
	<!-- inject:js -->
	<script src="/assets/js/off-canvas.js"></script>
	<script src="/assets/js/hoverable-collapse.js"></script>
	<script src="/assets/js/template.js"></script>
	<script src="/assets/js/settings.js"></script>
	<script src="/assets/js/todolist.js"></script>
	<!-- endinject -->
	<!-- Custom js for this page-->
	<script src="/assets/js/dashboard.js"></script>
	<!-- End custom js for this page-->
	<script>
        $(document).ready(function(){

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            
            $('.alert-dialog').click(function(){
                var message = $(this).attr('data-message');
                $("#delete-alert-modal #deleteAlertFrm").attr('action',$(this).attr('data-action'));
                $("#delete-alert-modal #deleteAlertFrm .modal-body").html(message);
                $("input[name=hdnResource]").val($(this).attr('data-id'));                
                $("input[name=hdnMetaData]").val($(this).attr('data-meta'));

                var delete_button = $("#delete-alert-modal button[type=submit]")

                var counter = 3;
                
                delete_button.text("Yes ("+counter+")").prop('disabled', true);

                setInterval(function() {
                    counter--;
                    if (counter > 0) {
                        delete_button.text("Yes ("+counter+")");
                    }

                    if (counter === 0) {
                        delete_button.text("Yes").prop('disabled', false);
                    }
                    
                }, 1000);

                $("#delete-alert-modal").modal('show');
            });

        });
    </script>
</body>

</html><?php /**PATH E:\Software\htdocs\admin-panel\blog\resources\views/layouts/app.blade.php ENDPATH**/ ?>