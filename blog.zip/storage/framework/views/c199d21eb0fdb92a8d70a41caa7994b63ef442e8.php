<?php $__env->startSection("title"); ?> Add Position <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <h4 class="card-title text-center">Update Position</h4>
        <hr>
        <div class="row">
            <div class="col-12">
                <div class="row grid-margin">
                    <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                        <h4 class="card-title"></h4>
                        <form class="cmxform" id="commentForm" method="post" action="<?php echo e(route('position-update')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <fieldset>
                            <?php echo $__env->make('websites.shipping.pages.positions.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                            <input type="hidden" name="id" value="1">
                            <input class="btn btn-success btn-block" type="submit" value="Update">
                            </fieldset>
                        </form>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-body">
        <h4 class="card-title text-center">View Position</h4>
        <hr>
        <div class="row">
            <div class="col-12">
                <div class="table-responsive">
                <table id="order-listing" class="table">
                    <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Position 1</th>
                        <th>Position 2</th>
                        <th>Position 3</th>
                        <!-- <th class="text-center" width="25%">Actions</th> -->
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>1</td>
                            <td><?php echo $position->text1; ?></td>
                            <td><?php echo $position->text2; ?></td>
                            <td><?php echo $position->text3; ?></td>
                            <!-- <td class="text-center">
                                <a href="<?php echo e(url('position/edit')); ?>/<?php echo e($position->id); ?>" class="btn btn-outline-primary">Edit</a>
                                <a href="<?php echo e(url('position/delete')); ?>/<?php echo e($position->id); ?>" class="btn btn-outline-danger" onclick="return confirm('Are you sure to delete ?')">Delete</a>
                            </td> -->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">No Records </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-panel\blog\resources\views/websites/shipping/pages/positions/list.blade.php ENDPATH**/ ?>