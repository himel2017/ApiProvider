<div class="form-group">
  <label for="text1">Position 1</label></textarea>
    <textarea class="form-control" name="text1"  id="text1" rows="3"><?php echo e(isset($position) ? $position->text1 : null); ?></textarea>
</div>
<div class="form-group">
  <label for="text2">Position 2</label></textarea>
    <textarea class="form-control" name="text2"  id="text2" rows="3"><?php echo e(isset($position) ? $position->text2 : null); ?></textarea>
</div>
<div class="form-group">
  <label for="text3">Position 3</label></textarea>
    <textarea class="form-control" name="text3"  id="text3" rows="3"><?php echo e(isset($position) ? $position->text3 : null); ?></textarea>
</div>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
      $('#text1').summernote({height: 200});
			$('#text2').summernote({height: 200});
			$('#text3').summernote({height: 200});
    });
</script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\admin-panel\blog\resources\views/websites/shipping/pages/positions/form.blade.php ENDPATH**/ ?>