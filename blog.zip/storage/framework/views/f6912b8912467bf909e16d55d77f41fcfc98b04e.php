<nav class="sidebar sidebar-offcanvas" id="sidebar">
	<ul class="nav">
		<li class="nav-item">
			<a class="nav-link" href="<?php echo e(url('/home')); ?>">
				<i class="mdi mdi-shield-check menu-icon"></i>
				<span class="menu-title">Dashboard</span>
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="<?php echo e(url('sidebars')); ?>">
				<i class="mdi mdi-format-line-spacing menu-icon"></i>
				<span class="menu-title">Sidebar Management</span>
			</a>
		</li>
		<?php $__empty_1 = true; $__currentLoopData = $sidebarContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidebarContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route($sidebarContent->link)); ?>">
					<i class="mdi mdi-content-paste menu-icon"></i>
					<span class="menu-title"><?php echo e($sidebarContent->title); ?></span>
				</a>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<li class="nav-item">
				<a class="nav-link" href="#">
					<i class="mdi mdi-code-not-equal-variant menu-icon"></i>
					<span class="menu-title">No Content Available</span>
				</a>
			</li>
		<?php endif; ?>		
		<!-- <li class="nav-item">
			<a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
				<i class="mdi mdi-view-array menu-icon"></i>
				<span class="menu-title">UI Elements</span>
				<i class="menu-arrow"></i>
			</a>
			<div class="collapse" id="ui-basic">
				<ul class="nav flex-column sub-menu">
					<li class="nav-item"> <a class="nav-link" href="#">Accordions</a></li>
					<li class="nav-item"> <a class="nav-link" href="#">Buttons</a></li>
				</ul>
			</div>
		</li> -->
	</ul>
	</nav><?php /**PATH C:\xampp\htdocs\admin-panel\blog\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>