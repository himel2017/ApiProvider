
<!-- DELETE ALERT MODAL -->
<div id="delete-alert-modal" class="modal fade">
    <div class="modal-dialog modal-md">
        <?php echo Form::open(['id'=>'deleteAlertFrm']); ?>

        <div class="modal-content">
            <!-- header modal -->
            <div class="modal-header">
                <h4 class="modal-title"><i class="mdi mdi-alert"></i> Are You Sure?</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <!-- body modal -->
            <div class="modal-body"></div>
            <!-- footer modal -->
            <div class="modal-footer">
                <?php echo Form::hidden('hdnResource'); ?>

                <?php echo Form::hidden('hdnMetaData'); ?>

                <button type="button" class="btn btn-sm btn-default waves-effect waves-light btn-rounded" data-dismiss="modal">No</button>
                <button type="submit" class="btn btn-sm btn-danger waves-effect waves-light btn-rounded">Yes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- Delete ALERT MODAL END --><?php /**PATH E:\Software\htdocs\admin-panel\blog\resources\views/layouts/partials/delete-alert-modal.blade.php ENDPATH**/ ?>