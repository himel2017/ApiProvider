<nav class="sidebar sidebar-offcanvas" id="sidebar">
<ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link d-flex">
              <div class="profile-image">
                <img src="https://www.akij.net/wp-content/uploads/2019/02/logo-60px.svg" alt="image">
              </div>
              <div class="profile-name">
                <p class="name">
                  Akij Group
                </p>
                <p class="designation">
                  Basic Admin Panel
                </p>
              </div>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
            <i class="mdi mdi-shield-check menu-icon"></i>
            <span class="menu-title">Dashboard</span>
            </a>
          </li>
        </ul>	
</nav><?php /**PATH C:\xampp\htdocs\blog\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>