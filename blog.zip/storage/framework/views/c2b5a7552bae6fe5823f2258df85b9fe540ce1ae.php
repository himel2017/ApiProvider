<nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
	<div class="text-left navbar-brand-wrapper d-flex align-items-center justify-content-between">
		<a class="navbar-brand brand-logo" href="<?php echo e(route('home')); ?>"><img src="<?php echo e($website->logo); ?>" alt="logo"/></a>
		<!-- <a class="navbar-brand brand-logo-mini" href="index.html"><img src="http://www.urbanui.com/hiliteui/template/images/logo-mini.svg" alt="logo"/></a>  -->
		<button class="navbar-toggler align-self-center" type="button" data-toggle="minimize">
		<span class="mdi mdi-menu"></span>
		</button>
	</div>
	<div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
		<ul class="navbar-nav">
		<li class="nav-item  dropdown d-none align-items-center d-lg-flex d-none">
			<!-- <a class="dropdown-toggle btn btn-outline-secondary btn-fw"  href="#" data-toggle="dropdown" id="pagesDropdown">
			<span class="nav-profile-name">Select Website</span>
			</a>
			<div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="pagesDropdown">
			<a class="dropdown-item">
			<i class="mdi mdi-settings text-primary"></i>
			Settings
			</a>
			<a class="dropdown-item">
			<i class="mdi mdi-logout text-primary"></i>
			Logout
			</a>
			</div> -->

			<?php echo Form::open(['url' => '/home/save']); ?>

				<label for="website_id"><p>Select Website</p></label>
				<?php echo Form::select("website_id", $websiteDropdownList, $website->id, ["class"=>"dropdown-toggle btn btn-outline-secondary btn-fw"]); ?>

				<button type="submit" class="btn btn-success">Submit</button>
			<?php echo Form::close(); ?>

		</li>
		</ul>
		<!-- <ul class="navbar-nav navbar-nav-right">
			<li class="nav-item nav-user-icon">
				<a class="nav-link" href="#">
				<img src="/assets/images/faces/face28.jpg" alt="profile"/>
				</a>
			</li>
		</ul> -->
		<ul class="navbar-nav ml-auto">
			<!-- Authentication Links -->
			<?php if(auth()->guard()->guest()): ?>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
				</li>
				<?php if(Route::has('register')): ?>
					<li class="nav-item">
						<a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
					</li>
				<?php endif; ?>
			<?php else: ?>
				<li class="nav-item dropdown">
					<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
						<?php echo e(Auth::user()->name); ?> <span class="caret"></span>
					</a>

					<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
							onclick="event.preventDefault();
											document.getElementById('logout-form').submit();">
							<?php echo e(__('Logout')); ?>

						</a>

						<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
							<?php echo csrf_field(); ?>
						</form>
					</div>
				</li>
			<?php endif; ?>
		</ul>
		<!-- <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
		<span class="mdi mdi-menu"></span>
		</button> -->
	</div>
	</nav><?php /**PATH E:\Software\htdocs\admin-panel\blog\resources\views/layouts/partials/menu.blade.php ENDPATH**/ ?>