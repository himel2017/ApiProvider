<?php $__env->startSection("title"); ?> Add Sidebar <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row grid-margin">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Add Sidebar</h4>
        <form class="cmxform" id="commentForm" method="post" action="<?php echo e(route('sidebar-save')); ?>">
          <?php echo e(csrf_field()); ?>

          <fieldset>
            <?php echo $__env->make('partials.sidebars.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <input class="btn btn-success" type="submit" value="Submit">
            <a href="<?php echo e(route('sidebars')); ?>" class="btn btn-primary">Back to list</a>
          </fieldset>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Software\htdocs\admin-panel\blog\resources\views/partials/sidebars/create.blade.php ENDPATH**/ ?>