<?php $__env->startSection("title"); ?> Add Position <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row grid-margin">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Add Position</h4>
        <form class="cmxform" id="commentForm" method="post" action="<?php echo e(route('position-update')); ?>">
          <?php echo e(csrf_field()); ?>

          <fieldset>
            <?php echo $__env->make('websites.shipping.pages.positions.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <input type="hidden" name="id" value="<?php echo e($position->id); ?>">
            <input class="btn btn-success" type="submit" value="Update">
            <a href="<?php echo e(route('positions')); ?>" class="btn btn-primary">Back to list</a>
          </fieldset>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-panel\blog\resources\views/websites/shipping/pages/positions/edit.blade.php ENDPATH**/ ?>