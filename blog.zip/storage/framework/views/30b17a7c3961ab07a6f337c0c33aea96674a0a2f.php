<?php $__env->startSection("title"); ?> Add Sidebar <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <h4 class="card-title text-center">Sidebar Create and View</h4>
        <hr>
        <div class="row">
        <div class="col-4">
            <div class="row grid-margin">
                <div class="col-lg-12">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Add Sidebar</h4>
                      <form class="cmxform" id="commentForm" method="post" action="<?php echo e(route('sidebar-save')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <fieldset>
                          <?php echo $__env->make('partials.sidebars.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                          
                          <input class="btn btn-success btn-block" type="submit" value="Submit">
                        </fieldset>
                      </form>
                    </div>
                  </div>
                </div>
            </div>
        </div>
        <div class="col-8">
            <div class="table-responsive">
            <table id="order-listing" class="table">
                <thead>
                <tr>
                    <th>Order #</th>
                    <th>Name</th>
                    <th class="text-center" width="25%">Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    $i = 1;
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $sidebars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidebar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($i); ?></td>
                        <td><a href="<?php echo e(route($sidebar->link)); ?>"><?php echo e($sidebar->title); ?></a></td>
                        <td class="text-center">
                            <a href="<?php echo e(url('sidebar/edit')); ?>/<?php echo e($sidebar->id); ?>" class="btn btn-outline-primary">Edit</a>
                            
                            <a href="<?php echo e(url('sidebar/delete')); ?>/<?php echo e($sidebar->id); ?>" class="btn btn-outline-danger" onclick="return confirm('Are you sure to delete ?')">Delete</a>
                        </td>
                    </tr>
                <?php
                    $i++;
                ?> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">No Records </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
            </div>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-panel\blog\resources\views/partials/sidebars/list.blade.php ENDPATH**/ ?>