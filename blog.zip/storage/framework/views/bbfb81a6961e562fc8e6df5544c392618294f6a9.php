<div class="form-group">
  <label for="title">Title (required)</label>
  <input id="title" class="form-control" name="title" type="text" value="<?php echo e(isset($sidebar) ? $sidebar->title : null); ?>" required>
</div>
<div class="form-group">
  <label for="link">Link (required)</label></textarea>
    <textarea class="form-control" name="link" id="link" rows="2"><?php echo e(isset($sidebar) ? $sidebar->link : null); ?></textarea>
</div>
<div class="form-group">
  <label for="parent_id">Parent (optional)</label>
  <?php echo Form::select("parent_id", $sidebarDropdownList, isset($sidebar) ? $sidebar->parent_id : null, ["class"=>"form-control", "placeholder"=>"--Select one--"]); ?>

</div><?php /**PATH C:\xampp\htdocs\admin-panel\blog\resources\views/partials/sidebars/form.blade.php ENDPATH**/ ?>