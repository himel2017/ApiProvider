<?php
/**
 * @OA\Tag(
 *     name="Greeting API",
 *     description="Sample package to test out the greeting APIs",
 * )
**/
?>
