<?php
/**
 * @OA\Info(
 *     description="API Documentation - Akij Group Admin Panel",
 *     version="1.0.0",
 *     title="Akij Group Admin Panel API Documentation",
 *     @OA\Contact(
 *         email="shakib.corp@akij.net"
 *     ),
 *     @OA\License(
 *         name="@Akij Group Admin Panel",
 *         url="http://test.com"
 *     )
 * )
 */