@extends('layouts.app')

@section("title") Dashboard @endsection

@section('content')
<div class="row">
    <div class="col-md-12">
    <div class="row">
        <div class="col-sm-6 mb-4 mb-xl-0">
            <h3>Welcome to Akij Group</h3>
            <h6 class="font-weight-normal mb-0 text-muted">Basic Admin Panel</h6>
        </div>
    </div>
    </div>
</div>
@endsection
